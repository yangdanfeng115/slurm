with open("slurm.conf.template", "r") as f:
    template = f.read()

nodes = ["slurmd1", "slurmd2"]
node_lines = "NodeName=" + ",".join(nodes) + " CPUs=2 State=UNKNOWN"

template = template.replace("#NODE_DEF", node_lines)

with open("slurm.conf", "w") as f:
    f.write(template)

print("✅ slurm.conf 生成完成")
