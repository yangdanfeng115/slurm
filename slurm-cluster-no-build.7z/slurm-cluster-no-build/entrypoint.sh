#!/bin/bash
set -e



# 修正权限
mkdir -p /var/log/munge
chown munge:munge /var/log/munge
chmod 0700 /var/log/munge

# 等一下以防 race condition
sleep 1

# 再检查一次
ls -ld /var/log/munge

# 创建必要目录及权限
mkdir -p /run/munge /var/log/munge
chown munge:munge /run/munge /var/log/munge
chmod 755 /run/munge
chmod 700 /var/log/munge

ls -l /etc/munge/munge.key

chown munge:munge /etc/munge/munge.key
chmod 400 /etc/munge/munge.key

ls -l /etc/munge/munge.key

ls -l /var/spool/slurm


# 启动 munge 作为 munge 用户
su -s /bin/bash munge -c 'munged'

# 启动 SSH 服务
service ssh start

# 启动 Slurm 服务
case "$HOSTNAME" in
  slurmctld)
    echo "Starting slurmctld..."
    slurmctld -D
    ;;
  slurmdb)
    echo "Starting slurmdbd..."
    slurmdbd -D
    ;;
  slurmd*)
    echo "Starting slurmd..."
    slurmd -D
    ;;
  *)
    echo "Unknown host role"
    tail -f /dev/null
    ;;
esac
